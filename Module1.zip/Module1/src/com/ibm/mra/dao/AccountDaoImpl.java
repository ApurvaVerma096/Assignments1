package com.ibm.mra.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import com.ibm.mra.bean.Account;

public class AccountDaoImpl<mobileNo,Account> implements AccountDao {

	Account ac;
	
	Map<String,Account> accountEntry=new HashMap<>();
	
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010210131", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9010210131", new Account("Prepaid", "Tushar", 632));
		
	
	Set<Entry<String, Account>> set = accountEntry.entrySet();

	ArrayList list;
	Iterator it;
	
	
	public Account getAccountDetails(String mobileNo) {
		for(Object obj:set) {
			Map.Entry mapEntry = (Map.Entry)obj;
			list.add(mapEntry.getValue());
			while(it.equals(mobileNo)) {
			if(mapEntry.getKey()==mobileNo) {
				
				String customerName= (String) mapEntry.getValue();
				String accountType = (String) mapEntry.getValue();
		double rechargeAmount = (double) mapEntry.getValue();
		return new Account(accountType ,customerName, rechargeAmount);
				
	}else {
		System.out.println("Your number is not Exist");
	}
			}
		}
	}
	
	@Override 
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		for(Object obj : set) {
			
		}
		
		return 0;
	}
	
}
