package com.ibm.mra.ui;

import java.util.Scanner;

import com.ibm.mra.service.AccountService;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUi {
	static AccountService as = new AccountServiceImpl();

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your choice : 1.Account Balance Enquiry 2.Recharge Account 3.Exit");
		int n = s.nextInt();
		do {
			switch(n) {
			case 1 : System.out.println("Enter your Mobile Number");
					String mobileNo = s.next();
					System.out.println("Your acc details is " + as.getAccountDetails(mobileNo));
					break;
			case 2 : System.out.println("Enter Your Mobile number");
					int mobileNo1 = s.nextInt();
					System.out.println("Enter the amount you want to recharge");
					double rehargeAmount = s.nextInt();
					System.out.println("your account Balance is "+ as.rechargeAccount(mobileNo1, rehargeAmount));
					break;
					
			case 3: System.exit(0);
				
			}
			
		}while(true);
	}

}
