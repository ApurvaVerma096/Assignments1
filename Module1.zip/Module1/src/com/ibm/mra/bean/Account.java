package com.ibm.mra.bean;

public class Account {

}
